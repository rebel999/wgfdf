package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Product;

public interface IproductDao {
	
	public List<Product> getAllProducts();
	public List<Product> deleteProductId(int productId);
	public List<Product> addProducts(Product product);
	public List<Product> updateProduct(Product product);

}
